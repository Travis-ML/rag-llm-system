# Git Setup Guide

Complete guide to set up Git and push your project to GitHub.

## Step 1: Install Git on Windows

### Option A: Using winget (Recommended)
```powershell
winget install --id Git.Git -e --source winget
```

### Option B: Manual Download
1. Download from https://git-scm.com/download/win
2. Run installer with default settings

### Verify Installation
```powershell
git --version
```

## Step 2: Configure Git

```powershell
# Set your GitHub username
git config --global user.name "Travis-ML"

# Set your GitHub email
git config --global user.email "your-email@example.com"

# Set default branch to main
git config --global init.defaultBranch main

# Verify configuration
git config --list
```

## Step 3: Initialize Local Repository

```powershell
# Navigate to your project
cd C:\Users\Travis\rag-llm\rag-system

# Initialize git repository
git init

# Add all files
git add .

# Create first commit
git commit -m "Initial commit: Local RAG system with Ollama, Qdrant, Open WebUI, SearXNG, and Jupyter"
```

## Step 4: Create GitHub Repository

### Option A: Using GitHub CLI (Easiest)

**Install GitHub CLI:**
```powershell
winget install --id GitHub.cli
```

**Authenticate and create repo:**
```powershell
# Login to GitHub
gh auth login
# Choose: GitHub.com → HTTPS → Yes → Login with browser

# Create repository and push
gh repo create rag-llm-system --public --source=. --remote=origin --push
```

### Option B: Manual Method

**On GitHub.com:**
1. Go to https://github.com/Travis-ML
2. Click **New Repository**
3. Repository name: `rag-llm-system`
4. Description: "Local RAG system with LLM, vector search, web search, and code execution"
5. Choose Public or Private
6. **Don't** initialize with README (you already have one)
7. Click **Create repository**

**Connect and push:**
```powershell
# Add remote
git remote add origin https://github.com/Travis-ML/rag-llm-system.git

# Push to GitHub
git branch -M main
git push -u origin main
```

## Step 5: Verify

Visit: https://github.com/Travis-ML/rag-llm-system

You should see your project with:
- ✅ README.md
- ✅ QUICKSTART.md
- ✅ docker-compose.yml
- ✅ rag-app/ folder
- ✅ .gitignore

## Common Git Commands

### Daily Workflow

```powershell
# Check status
git status

# Add changed files
git add .

# Commit changes
git commit -m "Description of changes"

# Push to GitHub
git push
```

### Managing Changes

```powershell
# See what changed
git diff

# View commit history
git log --oneline

# Undo unstaged changes
git checkout -- filename

# Undo last commit (keep changes)
git reset --soft HEAD~1
```

### Branching

```powershell
# Create new branch
git checkout -b feature-name

# Switch branches
git checkout main

# Merge branch
git merge feature-name

# Delete branch
git branch -d feature-name
```

## Project Structure for Git

```
rag-llm-system/
├── README.md              # Main documentation ✅
├── QUICKSTART.md          # Quick start guide ✅
├── .gitignore            # Ignore rules ✅
├── docker-compose.yml     # Docker config ✅
├── rag-app/              # Custom RAG API ✅
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── rag_server.py
│   └── process_pdfs.py
└── documents/            # PDFs (not committed) ❌
    └── .gitkeep          # Folder structure only ✅
```

## What Gets Committed vs Ignored

**Committed (in Git):**
- ✅ Source code
- ✅ Configuration files
- ✅ Documentation
- ✅ Dockerfile and docker-compose.yml
- ✅ Requirements.txt

**Ignored (not in Git):**
- ❌ PDF files (too large)
- ❌ Docker volumes/data
- ❌ Python cache files
- ❌ IDE settings
- ❌ Log files

## Making Updates

After making changes to your project:

```powershell
# 1. Check what changed
git status

# 2. Add changes
git add .

# 3. Commit with descriptive message
git commit -m "Add web search integration with SearXNG"

# 4. Push to GitHub
git push
```

## Authentication Methods

### HTTPS (Recommended for beginners)
- Uses personal access token
- Create at: https://github.com/settings/tokens
- Select scopes: `repo`, `workflow`

### SSH (Advanced)
```powershell
# Generate SSH key
ssh-keygen -t ed25519 -C "your-email@example.com"

# Add to GitHub
# Copy contents of ~/.ssh/id_ed25519.pub to GitHub SSH keys
```

## Troubleshooting

### Authentication Failed
- Use personal access token instead of password
- Get token from: https://github.com/settings/tokens

### Large Files Error
- PDFs are already in .gitignore
- If you committed large files by accident:
```powershell
git rm --cached filename
git commit -m "Remove large file"
```

### Conflicts
```powershell
# Pull latest changes
git pull

# Resolve conflicts in files
# Then:
git add .
git commit -m "Resolve conflicts"
git push
```

## Next Steps

1. ✅ Set up Git
2. ✅ Create GitHub repository
3. ✅ Push code
4. 📝 Add GitHub Actions for CI/CD (optional)
5. 📝 Create releases/tags (optional)
6. 📝 Add contributing guidelines (optional)

## Resources

- Git Documentation: https://git-scm.com/doc
- GitHub Guides: https://guides.github.com/
- GitHub CLI: https://cli.github.com/

---

Happy coding! 🚀
